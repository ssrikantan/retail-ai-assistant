#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
import os
import openai
class DefaultConfig:
    """ Bot Configuration """
    PORT = 3978
    APP_ID = os.environ.get("MicrosoftAppId", "3f7f460b-9063-44e3-8073-fc07345641a8")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "ocm8Q~z7ayCeeYdsClcsEqeWzbTKu.E0ZBe1ObP0")
    ai_search_url = "https://mtccogssearch.search.windows.net"
    ai_search_key = "f2f8PE1VeMR5fR0C1uCJXzgEY7tb81aO352GMh7daDAzSeBaFGO2"
    ai_index_name = "contoso-retail-index"
    ai_semantic_config = "contoso-retail-config"
    az_db_server = "cdcsampledbserver.database.windows.net"
    az_db_database = "cdcsampledb"
    az_db_username = "onepageradmin"
    az_db_password = "MtcPass$197235"
    az_openai_key = "da0643ec820a4745b8e1a4ebc364395c"
    az_openai_baseurl = "https://aoai-gpt4-001.openai.azure.com/"
    az_openai_version = "2024-02-15-preview" # required for the assistants API
    deployment_name = "gpt-4-turbo"  # T
    assistant_id = "asst_D7kSYGunSL2ISffaYVyFjVA6"